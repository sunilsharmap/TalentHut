##########################################################################
# Name	     : rtc_sys_GUI.py
# Date       : Wed Jul 20 18:21:30 IST 2016
# Author     : Mirafra
# Description: This is a python GUI script to update the System time to
#              RTC time or RTC time to System time
##########################################################################

#!/usr/bin/python

from Tkinter import *
import os
import re
import tkMessageBox
import subprocess


def rtc_to_sys():
    cmd = "sudo hwclock --hctosys"
    os.system(cmd)
    tkMessageBox.showinfo("Update", "Successfully updated\nRTC time to SYS time")

def sys_to_rtc():
    cmd = "sudo hwclock --systohc"
    os.system(cmd)
    tkMessageBox.showinfo("Update", "Successfully updated\nSYS time to RTC time")


if __name__ == "__main__":
    master = Tk()
    master.title("Time Setting")
    master.eval('tk::PlaceWindow %s center' % master.winfo_pathname(master.winfo_id()))

    Label(master, text=" RTC Time").grid(row=0, column=0)
    Label(master, text=" SYS Time").grid(row=1, column=0)

    RTC_box = Entry(master, bd = 3, justify='center', width=25, fg='black', bg='white')
    RTC_box.grid(row=0, column=1)

    SYS_box = Entry(master, bd = 3, justify='center', width=25, fg='black', bg='white')
    SYS_box.grid(row=1, column=1)
 
    Button(master, text = 'To SYS', command=rtc_to_sys, activeforeground='green', fg='black', bd=4).grid(row=0, column=5, sticky = W)
    Button(master, text='To RTC', command=sys_to_rtc, activeforeground='green', fg='black',bd=4).grid(row=1, column=5)
    Button(master, text='Quit', command=master.quit, activeforeground='red', fg='black', bd=4).grid(row=3, column=1)

    cmd = "sudo hwclock -r"
    rtc_time = subprocess.check_output(cmd, shell=True)
    patt = "((^\w{3} )(\d{2} )(\w{3} )(\d{4}) (\d{1,2}:\d{1,2}:\d{1,2} )(\w{1,3} ))"
    com_res = re.compile(patt, re.I)
    mat = com_res.match(rtc_time)
    rtc_time = mat.group(2) + mat.group(3) + mat.group(4) + mat.group(6) + mat.group(7) + mat.group(5)
    RTC_box.insert(0, rtc_time)
    RTC_box.config(state="readonly")

    cmd = "date"
    sys_time = subprocess.check_output(cmd, shell=True)
    sys_time = sys_time.replace("\n", "")
    SYS_box.insert(0, sys_time)
    SYS_box.config(state="readonly")

    mainloop( )


