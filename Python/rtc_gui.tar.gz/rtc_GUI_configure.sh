#!/bin/bash
touch ~/Desktop/rtc_gui.desktop

echo "[Desktop Entry]" > ~/Desktop/rtc_gui.desktop
echo "Version=1.0" >> ~/Desktop/rtc_gui.desktop
echo "Type=Application" >> ~/Desktop/rtc_gui.desktop
echo "Terminal=false" >> ~/Desktop/rtc_gui.desktop
echo "Exec=python /home/pi/rtc_gui/rtc_sys_GUI_v10.py" >> ~/Desktop/rtc_gui.desktop
echo "Name=RTC Time Update" >> ~/Desktop/rtc_gui.desktop
echo "Icon=/home/pi/rtc_gui/rtc.png" >> ~/Desktop/rtc_gui.desktop

sudo chmod +x ~/Desktop/rtc_gui.desktop
